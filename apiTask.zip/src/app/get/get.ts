import { Component, OnInit } from '@angular/core';
import { UserService } from '../user-service';
import { CommonModule } from '@angular/common';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-get',
  standalone : true,
  imports: [CommonModule],
  templateUrl: './get.html',
  styleUrl: './get.css'
})
export class Get implements OnInit {

  users : any[]=[];
  roles : any[]=[];
  error: string = '';

  constructor(private service : UserService){}
  
 ngOnInit(){
   this.fetchUsers();
 }

  fetchUsers(){
       forkJoin({
      users: this.service.getUsers(),
      roles: this.service.getRoles()
    }).subscribe({
      next: ({ users, roles }: any) => {
        this.roles = roles.data?.list || roles;
        this.users = (users.data?.list || users).map((user: any) => {
          const role = this.roles.find(r => r.id === user.role_id);
          return { ...user, role_name: role ? role.role_name : 'No role' };
        });
      },
      error: (err : any) => {
        console.error('Error fetching users or roles:', err);
        this.error = 'Failed to load users';
      }
    });
  }

}
