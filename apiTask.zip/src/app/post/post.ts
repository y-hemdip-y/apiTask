import { Component, OnInit } from '@angular/core';
import { UserService } from '../user-service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-post',
  standalone : true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './post.html',
  styleUrl: './post.css'
})
export class Post implements OnInit {

   userForm!: FormGroup;
  successMessage: string = '';
  errorMessage: string = '';
   selectedFile: File | null = null; 
     roles: any[] = [];

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    // Initialize form with validation
    this.userForm = new FormGroup({
      first_name: new FormControl('', [Validators.required, Validators.minLength(2)]),
      last_name: new FormControl('', [Validators.required, Validators.minLength(2)]),
      email: new FormControl('', [Validators.required, Validators.email]),
      dial_code: new FormControl('+91', Validators.required),
      phone_number: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]),
      gender: new FormControl('male', Validators.required),
      user_type: new FormControl('4', Validators.required),
      password: new FormControl('', [Validators.required, Validators.minLength(6)])
    });

     this.userService.getRoles().subscribe((res: any) => {
    this.roles = res.data.list || res; // assign API result to roles
  });
  }



  submitForm() {
    this.successMessage = '';
    this.errorMessage = '';

    if (this.userForm.invalid) {
      this.errorMessage = 'Please fix the errors in the form before submitting';
      return;
    }

     const selectedRoleName = this.userForm.value.role_id; // currently holds role name from dropdown
    const selectedRole = this.roles.find(r => r.role_name === selectedRoleName);
 

    // Replace role name with role ID in payload
    const payload = { ...this.userForm.value, role_id: selectedRole.id };


    this.userService.createUser(this.userForm.value).subscribe({
      next: (res) => {
        this.successMessage = 'User created successfully!';
        this.userForm.reset({ dial_code: '+91', gender: 'male', user_type: '4' });
      },
      error: (err) => {
        this.errorMessage = 'Failed to create user';
        console.error('Error:', err);
      }
    });
  }
}
